

ClusterQuality <- function (version = 1, use.ideal = FALSE, use.random = FALSE) {
    
    species.mins <- GetTags();
    species.mins <- AddMinuteIdCol(species.mins)
    if (use.ideal) {
        group.mins <- SimulatePerfectClustering(species.mins)
    } else {
        if (use.random) {
            events <- ApplyRandomGroupToEvents()
        } else {
            events <- ApplyGroupToEvents()
        }
        
        cluster.mins <- events$data[c('min.id', 'group')]
        group.mins <- unique(cluster.mins)  
    }
    groups <- unique(group.mins$group)
    species <- unique(species.mins$species.id)
    species <- data.frame(species.id = species[order(species)])
    species$min.count <- sapply(species$species.id, function (s.id) {
        return(sum(species.mins$species.id == s.id))
    })
    groups <- data.frame(group = groups[order(groups)])
    groups$min.count <- sapply(groups$group, function (group) {
        return(sum(group.mins$group == group))
    })
    
    
    m <- matrix(NA, nrow = nrow(species), ncol = nrow(groups))
    
    
    
    for (s in 1:nrow(species)) {
        Dot()
        
   
        
        for (g in 1:nrow(groups)) {
            
            mins.with.species <- species.mins$min.id[species.mins$species.id == species$species.id[s]] 
            mins.with.group <- group.mins$min.id[group.mins$group == groups$group[g]] 
            mins.with.both <- intersect(mins.with.species, mins.with.group)
            
            over.species.val <- length(mins.with.both)/length(mins.with.species)  
            over.group.val <- length(mins.with.both)/length(mins.with.species)  

            
            
            if (version == 1) {
                title <- "Num mins containing both divided by num mins containg species"
                m[s,g] <- over.species.val
            } else if (version == 2) {
                title <- "Num mins containing both divided by num mins containg group"
                m[s,g] <- over.group.val
            } else if (version == 3) {
                m[s,g] <- MatchSpeciesGroup2(species.id = species$species.id[s], group = groups$group[g], species.mins, group.mins)
            } else if (version == 4) {
                m[s,g] <- MatchSpeciesGroup3(species.id = species$species.id[s], group = groups$group[g], species.mins, group.mins)
            }
        }
    }
    
    DrawCQMatrix.5(m, species, groups, title)
    
    return(list(m = m, species = species, groups = groups$group, title = title))
    
}

DrawCQMatrix.4 <- function (m, species, groups, title) {
    require(lattice)
    m <- m
    levelplot(m, 
              col.regions=gray.colors(256,start=1,end=0), 
              xlab = "Cluster Groups",
              ylab = "Species id",
              row.values = species,
              column.values = groups)
    
    
}

DrawCQMatrix.3 <- function (m, species, groups, title) {
    
    image(t(m), col=gray.colors(256,start=1,end=0), axes = FALSE, useRaster = TRUE)
    
    at.x <- 1:ncol(m) / ncol(m)
    at.y <- 1:nrow(m) / nrow(m)
    
    #axis(3, at = at.x, labels=as.character(groups), srt=45,tick=FALSE)
    #axis(2, at = at.y, labels=as.character(species), srt=45,tick=FALSE)
    
    mtext("species", 2, line=0)
    mtext("clusters", 1, line=0)
    
    mtext('title')
    
}

DrawCQMatrix.5 <- function (m, species, groups, title) {
    require('grid')
    #ma <- max(m)
    #mi <- min(m)  
    #raster renders higher values as white, so lets inverse
    #amp <- - (((m - mi) / (ma - mi)) - 1)
    
    vals <- m
    
    grid.newpage()
    scale <- 5
    #devsize.cm <- dev.size(units = "cm")
    #devsize.px <- dev.size(units = "px")
    #px.per.cm <- (devsize.px[1] / devsize.cm[1]) / 10
    #vp.width.cm <- ncol(vals) / px.per.cm
    #vp.height.cm <- nrow(vals) / px.per.cm
    container.vp <- viewport(x = 0.5, y = 0.5, width=1, height=1, just = c('center', 'center'), default.units = 'npc')
    pushViewport(container.vp)
    grid.show.viewport(container.vp)
    vp <- viewport(x = 0.5, y = 0.5, width=0.8, height=0.8, just = c('center', 'center'), default.units = 'npc')

    pushViewport(vp)
    grid.show.viewport(vp)   
    grid.raster(image = vals, x = unit(0.5, "npc"), y = unit(0.5, "npc"), width = 1, height = 1, vp = vp, interpolate = FALSE)
    
    
    
  #  at.x <- 1:ncol(vals) / ncol(vals)
  #  at.y <- 1:nrow(vals) / nrow(vals)
    
    #axis(3, at = at.x, labels=as.character(groups), srt=45,tick=FALSE)
    #axis(2, at = at.y, labels=as.character(species), srt=45,tick=FALSE)
    
 #   mtext("species", 2, line=0)
 #   mtext("clusters", 1, line=0)
    
  #  mtext('title')
    
}


DrawCQMatrix.2 <- function (m, species, groups) { 
    library(pheatmap)
    m <- m
    pheatmap(m, cluster_row = FALSE, cluster_col = FALSE, color=gray.colors(256,start=1,end=0), scale = 'none')
}

DrawCQMatrix.1 <- function (m, species, groups) { 
    library(gplots)
    #Format the data for the plot
    xval <- formatC(m, format="f", digits=2)
    pal <- colorRampPalette(c(rgb(0.96,0.96,1), rgb(0,0,0)), space = "rgb")
    #Plot the matrix
    x_hm <- heatmap.2(m, 
                      Rowv=FALSE, 
                      Colv=FALSE, 
                      dendrogram="none", 
                      main="8 X 8 Matrix Using Heatmap.2", 
                      xlab="Cluster", 
                      ylab="Species", 
                      col=pal, 
                      tracecol="#303030", 
                      trace="none", 
                      cellnote=xval, 
                      notecol="black", 
                      notecex=0.8, 
                      keysize = 1.5, 
                      margins=c(5, 5))
    
}


SetupArtificialClustering <- function (species.mins = NULL) {
    # returns a list of call - minute pairs by randomly assigning 1 or more call(type)s to each species
    #
    
    
    if (is.null(species.mins)) {
        species.mins <- GetTags();
        species.mins <- AddMinuteIdCol(species.mins)
    } 
    
    
    # create dataframe with counts of each species, ordered by species id
    species.ids <- as.data.frame(table(species.mins$species.id))
    colnames(species.ids) <- c('species.id', 'count')
    species.ids <- species.ids[order(species.ids$species.id), ]
    
    # get rid of extra columns in species.mins
    species.mins <- species.mins[, c('species.id', 'min.id')]
    
    
    # create a list of "calls" call belongs to species, species has many calls
    # arbitrary number of calls to be 2xnumber of species
    call.ids <- 1:(nrow(species.ids)*2)
    
    # assign a species id to each call. 
    # species appearing in fewer than x mins will only be assigned to 1 call, to reduce the chance of a species having more calls than mins it appears in
    x <- 8
    frequent.species <- species.ids[species.ids$count >= x, ]
    rare.species <- species.ids[species.ids$count < x, ]
    call.ids.for.rare.species <- call.ids[1:nrow(rare.species)]
    call.ids.for.frequent.species <- call.ids[(length(call.ids.for.rare.species) + 1):length(call.ids)]
    
    ok <- FALSE
    num <- 0
    while (!ok && num < 50) {
        calls.of.frequent.species <- data.frame(call.id = call.ids.for.frequent.species, 
                                                species.id = sample(frequent.species$species.id, length(call.ids.for.frequent.species), replace = TRUE))
        # ensure all species have at least 1 call
        # select random indices of the list of calls of frequent species 
        indices <- sample(1:length(call.ids.for.frequent.species), nrow(frequent.species), replace = FALSE)
        # assign each species to those random indices
        calls.of.frequent.species$species.id[indices] <- sample(frequent.species$species.id, nrow(frequent.species), replace = FALSE)
        # check that no species has more calls than mins it appears in
        # freaky random sampling may have done this, but unlikely
        call.count <- as.data.frame(table(as.integer(calls.of.frequent.species$species.id)))
        colnames(call.count) <- c('species.id', 'count')
        call.count <- call.count[order(call.count$species.id), ]
        if (all(call.count$count <= frequent.species$count)) {
            ok <- TRUE
        }
        num <- num + 1
    }
    
    calls.of.rare.species <- data.frame(call.id = call.ids.for.rare.species, 
                                        species.id = as.integer(as.character(rare.species$species.id)))
    
    calls <- rbind(calls.of.rare.species, calls.of.frequent.species)
    
    return(list(calls = calls, species.mins = species.mins, species.ids = species.ids))
    
    
}

SimulatePerfectClustering <- function (species.mins = NULL) {
    # given a list of species-minute pairs, will create a list of cluster-minute pairs
    # to simulate perfect clustering
    #
    # Args:
    #   species.mins: data.frame: contains cols species.id and min.id
    #
    # Value:
    #   data.frame: list of group - minute pairs
    #
    # Details: 
    #   if species.mins is ommited, will get them again from the database
    
    
    res <- SetupArtificialClustering(species.mins)
    calls <- res$calls
    species.ids <- res$species.ids
    speceis.mins <- res$species.mins
    
    # each call has 1 or more events. Each event belongs to 1 cluster. So, each call has 1 or more clusters. each cluster belongs to 1 call
    
    cluster.ids <- 1:(nrow(calls) * 2)
    clusters <- data.frame(cluster.id = cluster.ids, call.id = SampleAtLeastOne(calls$call.id, nrow(calls)))
    
    clusters$call.id[sample(1:nrow(clusters), nrow(calls), replace = FALSE)] = sample(calls$call.id, nrow(calls), replace = FALSE)  # ensure all calls have at least 1 cluster
    
    # so, now we have each species with 1 or more calls (average of 2)
    # and each call has 1 or more cluster groups (average of 2)
    # assume that in any particular minute, only one call from each species is present. i.e. a species won't call with 2 different call types in the same minute
    

    
    # for each species-minute pair, assign a call.id
    # then add the relevant events to the cluster.minutes df
    species.mins$call.id <- rep(NA, nrow(species.mins))
    for (s.id in as.numeric(as.character(species.ids$species.id))) {   
        species.mins.rows <- which(species.mins$species.id == s.id) 
        species.call.ids <- calls$call.id[calls$species.id == s.id]
        
        if (length(species.call.ids) == 1) {
            species.mins$call.id[species.mins.rows] <- species.call.ids
        } else {
            #if the species has more than one call, randomly assign the calls to the minutes of that species
            # but make sure to include each call id at least once
            
            
            species.mins$call.id[species.mins.rows] <- SampleAtLeastOne(species.call.ids, length(species.mins.rows))
        }                                  
    }
    
    # create a list of cluster-minute pairs
    cluster.minutes <- data.frame(min.id = integer(), group = integer())
    
    for (i in 1:nrow(calls)) {
        this.species.mins <- species.mins[species.mins$call.id == calls$call.id[i], ]
        this.clusters <- clusters[clusters$call.id == calls$call.id[i], ]
        this.cluster.minutes <- data.frame(min.id = rep(this.species.mins$min.id, times = nrow(this.clusters)),  group = rep(this.clusters$cluster.id, times = 1, each = nrow(this.species.mins)))
        cluster.minutes <- rbind(cluster.minutes, this.cluster.minutes)
    }


    
    return(cluster.minutes)

    
}




MatchSpeciesGroup <- function (species.id, group, species.mins, group.mins, over.species = TRUE) {
    # finds the number of minutes containing both particular species and a particular group
    # divided by the number of minutes containing the species
    # OR
    # the number of mins containing both divided by the number of mins containing the group
    
    mins.with.species <- species.mins$min.id[species.mins$species.id == species.id] 
    mins.with.group <- group.mins$min.id[group.mins$group == group] 
    mins.with.both <- intersect(mins.with.species, mins.with.group)
    
    return(list(mins.with.species = mins.with.species,
                mins.with.group = mins.with.group,
                mins.with.both = mins.with.both))
    


}

MatchSpeciesGroup2 <- function (species.id, group, species.mins, group.mins) {
    # 
    
    total.num.mins <- length(unique(c(species.mins$min.id, group.mins$min.id)))
    
    mins.with.species <- species.mins$min.id[species.mins$species.id == species.id]
    mins.with.group <- group.mins$min.id[group.mins$group == group] 
    mins.with.both <- intersect(mins.with.species, mins.with.group)
    
    chance.of.both.if.random <- (length(mins.with.species)/total.num.mins) * (length(mins.with.group)/total.num.mins)
    
    #score <-  (chance.of.both.if.random ) /  ((length(mins.with.both) / total.num.mins) + )
    
    score <- (length(mins.with.both) / total.num.mins) / chance.of.both.if.random
    
    
    return(score)
    
}

MatchSpeciesGroup3 <- function (species.id, group, species.mins, group.mins) {
    # 
    
    mins.with.species <- species.mins$min.id[species.mins$species.id == species.id]
    mins.with.group <- group.mins$min.id[group.mins$group == group] 
    mins.with.both <- intersect(mins.with.species, mins.with.group)
    
    #score <-  (chance.of.both.if.random ) /  ((length(mins.with.both) / total.num.mins) + )
    
    score <- length(mins.with.both)^2 / (length(mins.with.species) * length(mins.with.group))
    
    return(score)
    
}


ApplyGroupToEvents <- function (num.cluster.groups = 240, events = NA, clustering = NA) {
    # given a df of events and a clustering object,  adds a 'group' column to the events df 
    # using the specified number of cluster groups
    #
    # Args:
    #   num.cluster.groups: int
    #   events: data.frame
    #   clustering: clustering.object
    #
    # Value:
    #   data frame: the events data frame with the group number for each event
    #
    # Details: 
    #   if events or clutering is ommited, these will both be obtained by reading output 
    #
    
    if (!is.data.frame(events)) {
        events <- ReadOutput('events')
        fit <- ReadOutput('clustering')
    } 
    group <- cutree(fit$data, num.cluster.groups)
    events$data$group <- group #temporarily add the group to the events for ranking
    return(events)
}

ApplyRandomGroupToEvents <- function (num.cluster.groups = 240, events = NA) {
    # given a df of events and a clustering object,  adds a 'group' column to the events df 
    # using the specified number of cluster groups
    #
    # Args:
    #   num.cluster.groups: int
    #   events: data.frame
    #
    # Value:
    #   data frame: the events data frame with the group number for each event
    #
    # Details: 
    #   if events is ommited it will be obtained by reading output 
    #
    
    if (!is.data.frame(events)) {
        events <- ReadOutput('events')
    } 
    group <- SampleAtLeastOne(1:num.cluster.groups, nrow(events$data))
    events$data$group <- group
    return(events)
}



InspectCountEventsByGroupInMins <- function () {
    events <- ApplyGroupToEvents()
    counts <- CountEventsByGroupInMins(c(), events)
    counts <- counts[order(counts$all.events.count),]
    plot(counts$all.events.count)
}


CountEventsByGroupInMins <- function (min.ids, all.events) {
    minute.events <- all.events[all.events$min.id %in% min.ids, ]
    group.ids <- min(all.events$group):max(all.events$group)
    counts <- data.frame(group.id = group.ids, all.events.count = group.ids, minute.events.count = group.ids)
    if (group.ids != 1:max(all.events$group)) {
        # make sure group ids go from 1 to the maximum with no gaps
        # this might be caused by passing only some of the events
        # this would still fail events were excluded that included the only 
        # examples of the group with the highest id
        stop("something is wrong. some cluster groups are missing")
    }
    for (gid in group.ids) {       
        counts$all.events.count[gid] <- sum(all.events$group == gid)
        counts$minute.events.count[gid] <- sum(minute.events$group == gid)
    }
    return(counts)
}


InspectEventsPerGroupAllMins <- function () {
    events <- ApplyGroupToEvents()
    event.count.all.mins <- EventsPerGroupAllMins(events)
}



EventsPerGroupAllMins <- function (events) {
    min.ids <- unique(events$min.id)
    group.ids <- min(events$group):max(events$group)
    count.matrix = matrix(NA, ncol = length(group.ids), nrow = length(min.ids))
    for (i in 1:length(min.ids)) {
        minute.events <- events[events$min.id == min.ids[i], ]
        event.count.vector <- EventsPerGroup(minute.events, group.ids)
        count.matrix[i ,] <- event.count.vector
    }
    
    return(list(
        min.ids <- min.ids,
        event.counts <- count.matrix 
        ))
}

EventsPerGroup <- function (events, group.ids) {    
    count <- rep(NA, length(group.ids))
    
    
    for (i in group.ids) {       
        count[i] <- sum(events$group == group.ids[i])      
    }  
    return(count) 
}